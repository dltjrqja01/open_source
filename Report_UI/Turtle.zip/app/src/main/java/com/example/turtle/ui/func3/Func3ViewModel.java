package com.example.turtle.ui.func3;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class Func3ViewModel extends ViewModel {


    public Func3ViewModel() {
    }

}