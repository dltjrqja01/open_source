package com.example.turtle.ui.func2;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class Func2ViewModel extends ViewModel {

    public Func2ViewModel() {
    }

}